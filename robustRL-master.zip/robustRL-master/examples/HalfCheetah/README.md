Example on the HalfCheeta-v1 task specified here: https://gym.openai.com/envs/HalfCheetah-v1
