from .simple_humanoid_env import SimpleHumanoidEnv


# Taken from Wojciech's code
class HumanoidEnv(SimpleHumanoidEnv):

    FILE = 'humanoid.xml'
