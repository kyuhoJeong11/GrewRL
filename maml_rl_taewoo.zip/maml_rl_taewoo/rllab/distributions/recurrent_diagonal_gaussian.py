import theano.tensor as TT
import numpy as np
from rllab.distributions.base import Distribution
from rllab.distributions.diagonal_gaussian import DiagonalGaussian

RecurrentDiagonalGaussian = DiagonalGaussian
